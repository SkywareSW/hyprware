#!/usr/bin/env bash
##############################################
#   hyprware — screen recorder toggle       #
##############################################
#   Uses wf-recorder. Toggle record on/off.
#   Output: ~/Videos/Recordings/
##############################################

OUTPUT_DIR="$HOME/Videos/Recordings"
mkdir -p "$OUTPUT_DIR"

TIMESTAMP=$(date +%Y-%m-%d_%H-%M-%S)
OUTPUT_FILE="$OUTPUT_DIR/recording_$TIMESTAMP.mp4"

if pgrep -x wf-recorder > /dev/null; then
    # Stop recording
    pkill -SIGINT wf-recorder
    sleep 0.5
    notify-send "Recording" "Saved to ~/Videos/Recordings/" -i camera-video -t 4000
else
    # Offer region or fullscreen
    CHOICE=$(printf "Fullscreen\nRegion\nWindow" \
        | rofi -dmenu -p "Record" -config ~/.config/rofi/launcher.rasi \
               -theme-str 'window { width: 200px; } listview { lines: 3; }')

    case "$CHOICE" in
        "Fullscreen")
            notify-send "Recording" "Started (fullscreen)" -i camera-video -t 2000
            wf-recorder -f "$OUTPUT_FILE" -c libx264 -p preset=fast &
            ;;
        "Region")
            GEOM=$(slurp)
            [[ -z "$GEOM" ]] && exit 1
            notify-send "Recording" "Started (region)" -i camera-video -t 2000
            wf-recorder -g "$GEOM" -f "$OUTPUT_FILE" -c libx264 -p preset=fast &
            ;;
        "Window")
            GEOM=$(hyprctl activewindow -j | python3 -c "
import json, sys
w = json.load(sys.stdin)
a = w['at']; s = w['size']
print(f'{a[0]},{a[1]} {s[0]}x{s[1]}')
")
            notify-send "Recording" "Started (window)" -i camera-video -t 2000
            wf-recorder -g "$GEOM" -f "$OUTPUT_FILE" -c libx264 -p preset=fast &
            ;;
        *) exit 0 ;;
    esac
fi
