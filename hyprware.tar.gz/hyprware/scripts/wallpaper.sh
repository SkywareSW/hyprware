#!/usr/bin/env bash
##############################################
#   hyprware — wallpaper rotation script    #
##############################################
#   Randomly picks a wallpaper from
#   ~/.config/hypr/wallpapers/ and applies it
#   via hyprpaper (live, no restart needed).
##############################################

WALLPAPER_DIR="$HOME/.config/hypr/wallpapers"

# Ensure directory exists
if [[ ! -d "$WALLPAPER_DIR" ]]; then
    echo "Wallpaper directory not found: $WALLPAPER_DIR"
    exit 1
fi

# Pick random wallpaper
WALLPAPER=$(find "$WALLPAPER_DIR" -type f \( \
    -iname "*.jpg" -o -iname "*.jpeg" -o \
    -iname "*.png" -o -iname "*.webp" \
\) | shuf -n1)

if [[ -z "$WALLPAPER" ]]; then
    echo "No wallpapers found in $WALLPAPER_DIR"
    exit 1
fi

# Apply to all monitors via hyprpaper IPC
MONITORS=$(hyprctl monitors -j | python3 -c "
import json, sys
for m in json.load(sys.stdin):
    print(m['name'])
")

for monitor in $MONITORS; do
    hyprctl hyprpaper preload  "$WALLPAPER"
    hyprctl hyprpaper wallpaper "$monitor,$WALLPAPER"
done

notify-send -i "$WALLPAPER" "Wallpaper" "Changed to $(basename "$WALLPAPER")" -t 2000
