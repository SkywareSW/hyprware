#!/usr/bin/env python3
"""
Waybar media player module — hyprware
Outputs JSON for the custom/media module.
"""

import json
import sys
import signal
import gi
gi.require_version("Playerctl", "2.0")
from gi.repository import Playerctl, GLib

manager = Playerctl.PlayerManager()

PLAYER_ICONS = {
    "spotify": "󰓇",
    "firefox": "󰈹",
    "chromium": "󰊯",
    "vlc": "󰕼",
    "mpv": "󰐌",
    "rhythmbox": "󰓃",
    "default": "󰎄",
}


def get_icon(player_name: str) -> str:
    name = player_name.lower()
    for key, icon in PLAYER_ICONS.items():
        if key in name:
            return icon
    return PLAYER_ICONS["default"]


def get_status_icon(status: str) -> str:
    return {"Playing": "󰐊", "Paused": "󰏤", "Stopped": "󰓛"}.get(status, "")


def on_metadata(player, metadata, manager):
    output()


def on_playback_status(player, status, manager):
    output()


def output():
    for player in manager.props.players:
        try:
            name   = player.props.player_name
            status = player.props.playback_status.value_nick.capitalize()
            meta   = player.props.metadata

            title  = meta.lookup_value("xesam:title", None)
            artist = meta.lookup_value("xesam:artist", None)

            title_str  = title.get_string()  if title  else ""
            artist_str = artist.get_strv()[0] if artist and artist.get_strv() else ""

            if not title_str and not artist_str:
                continue

            text    = f"{artist_str} — {title_str}" if artist_str else title_str
            tooltip = f"{get_icon(name)} {name.capitalize()}\n{text}"

            print(json.dumps({
                "text":       f"{get_status_icon(status)} {text[:40]}{'…' if len(text) > 40 else ''}",
                "tooltip":    tooltip,
                "alt":        status.lower(),
                "class":      status.lower(),
            }), flush=True)
            return

        except Exception:
            continue

    print(json.dumps({"text": "", "tooltip": "", "class": "stopped"}), flush=True)


def on_name_appeared(manager, name):
    player = Playerctl.Player.new_from_name(name)
    player.connect("metadata",         on_metadata,        manager)
    player.connect("playback-status",  on_playback_status, manager)
    manager.manage_player(player)
    output()


def on_name_vanished(manager, name):
    output()


def main():
    signal.signal(signal.SIGINT, signal.SIG_DFL)
    manager.connect("name-appeared", on_name_appeared)
    manager.connect("name-vanished", on_name_vanished)

    for name in manager.props.player_names:
        on_name_appeared(manager, name)

    output()
    GLib.MainLoop().run()


if __name__ == "__main__":
    main()
