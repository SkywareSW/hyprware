#!/usr/bin/env bash
# hyprware — WiFi toggle
WIFI_STATUS=$(nmcli radio wifi)
if [[ "$WIFI_STATUS" == "enabled" ]]; then
    nmcli radio wifi off
    notify-send "WiFi" "Disabled" -i network-wireless-offline -t 2000
else
    nmcli radio wifi on
    notify-send "WiFi" "Enabled" -i network-wireless -t 2000
fi
