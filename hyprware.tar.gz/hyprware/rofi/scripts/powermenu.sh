#!/usr/bin/env bash
##############################################
#   hyprware — Rofi Power Menu              #
##############################################

LOCK="  Lock"
SLEEP="󰒲  Sleep"
LOGOUT="  Logout"
REBOOT="  Reboot"
SHUTDOWN="  Shutdown"

CHOSEN=$(printf "$LOCK\n$SLEEP\n$LOGOUT\n$REBOOT\n$SHUTDOWN" \
  | rofi -dmenu \
         -p "Power" \
         -config ~/.config/rofi/launcher.rasi \
         -theme-str '
window { width: 240px; }
listview { lines: 5; }
')

case "$CHOSEN" in
    "$LOCK")     loginctl lock-session ;;
    "$SLEEP")    systemctl suspend ;;
    "$LOGOUT")   hyprctl dispatch exit ;;
    "$REBOOT")
        notify-send -t 3000 "System" "Rebooting…"
        sleep 1 && systemctl reboot ;;
    "$SHUTDOWN")
        notify-send -t 3000 "System" "Shutting down…"
        sleep 1 && systemctl poweroff ;;
esac
