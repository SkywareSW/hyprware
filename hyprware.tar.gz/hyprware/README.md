# hyprware

```
██╗  ██╗██╗   ██╗██████╗ ██╗    ██╗ █████╗ ██████╗ ███████╗
██║  ██║╚██╗ ██╔╝██╔══██╗██║    ██║██╔══██╗██╔══██╗██╔════╝
███████║ ╚████╔╝ ██████╔╝██║ █╗ ██║███████║██████╔╝█████╗  
██╔══██║  ╚██╔╝  ██╔═══╝ ██║███╗██║██╔══██║██╔══██╗██╔══╝  
██║  ██║   ██║   ██║     ╚███╔███╔╝██║  ██║██║  ██║███████╗
╚═╝  ╚═╝   ╚═╝   ╚═╝      ╚══╝╚══╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝
```

**Hyprland dotfiles — Catppuccin Mocha — optimized for speed, beauty, and daily use.**

---

## Stack

| Component | Package |
|---|---|
| Compositor | `hyprland` |
| Status bar | `waybar` |
| App launcher | `rofi-wayland` |
| Notifications | `dunst` |
| Terminal | `kitty` |
| Lock screen | `hyprlock` |
| Idle daemon | `hypridle` |
| Wallpaper | `hyprpaper` |
| Color picker | `hyprpicker` |
| Screenshot | `hyprshot` + `grim` + `slurp` |
| Screen record | `wf-recorder` |
| Clipboard | `cliphist` + `wl-clipboard` |
| Theme | Catppuccin Mocha |
| Font | JetBrainsMono Nerd Font |
| Icons | Papirus-Dark |
| Cursor | Bibata-Modern-Ice |

---

## Quick Install

```bash
git clone https://github.com/youruser/hyprware.git ~/.dotfiles/hyprware
cd ~/.dotfiles/hyprware
chmod +x install.sh
./install.sh
```

> **Arch Linux only.** Requires `pacman` + either `yay` or `paru` (installer will set up yay if missing).

---

## File Structure

```
hyprware/
├── install.sh                  # One-shot installer
├── hypr/
│   ├── hyprland.conf           # Main Hyprland config
│   ├── mocha.conf              # Catppuccin color theme
│   ├── hyprlock.conf           # Lock screen
│   ├── hypridle.conf           # Idle/sleep management
│   ├── hyprpaper.conf          # Wallpaper daemon
│   └── scripts/
│       ├── wallpaper.sh        # Random wallpaper rotation
│       └── record.sh           # Screen recording toggle
├── waybar/
│   ├── config.jsonc            # Waybar modules config
│   ├── style.css               # Waybar stylesheet
│   ├── mocha.css               # Catppuccin CSS variables
│   └── scripts/
│       ├── mediaplayer.py      # Now-playing module
│       └── toggle_wifi.sh      # WiFi toggle
├── rofi/
│   ├── launcher.rasi           # App launcher theme
│   ├── mocha.rasi              # Color palette
│   └── scripts/
│       └── powermenu.sh        # Power menu
├── dunst/
│   └── dunstrc                 # Notification daemon
└── kitty/
    └── kitty.conf              # Terminal config
```

---

## Key Bindings

### Window Management
| Binding | Action |
|---|---|
| `Super + H/J/K/L` | Move focus (vim-style) |
| `Super + Shift + H/J/K/L` | Move window |
| `Super + Ctrl + H/J/K/L` | Resize window |
| `Super + F` | Fullscreen |
| `Super + Alt + F` | Toggle float |
| `Super + P` | Pseudotile |
| `Super + T` | Toggle split |
| `Super + G` | Toggle group |
| `Super + Z` | Pin window |
| `Super + Q` | Close window |

### Workspaces
| Binding | Action |
|---|---|
| `Super + [1-0]` | Switch workspace |
| `Super + Shift + [1-0]` | Move to workspace |
| `Super + [ / ]` | Previous / next workspace |
| `Super + grave` | Last workspace |
| `Super + S` | Scratchpad toggle |
| `Super + Shift + S` | Move to scratchpad |

### Apps
| Binding | Action |
|---|---|
| `Super + Return` | Terminal |
| `Super + Shift + Return` | Floating terminal |
| `Super + Space` | App launcher |
| `Super + Tab` | Window switcher |
| `Super + B` | Browser |
| `Super + E` | File manager |
| `Super + C` | Code editor |
| `Super + V` | Clipboard history |

### Utilities
| Binding | Action |
|---|---|
| `Print` | Screenshot (output) |
| `Shift + Print` | Screenshot (region) |
| `Super + Shift + S` | Screenshot to clipboard |
| `Super + Alt + R` | Record screen (toggle) |
| `Super + Shift + C` | Color picker |
| `Super + W` | Random wallpaper |
| `Super + Ctrl + L` | Lock screen |
| `Super + Shift + E` | Power menu |
| `Super + Shift + R` | Reload Hyprland config |

---

## Customization

### Monitors
Edit `~/.config/hypr/hyprland.conf`:
```ini
# Remove or comment the auto line:
# monitor = ,preferred,auto,1

# Add your monitors:
monitor = DP-1,2560x1440@165,0x0,1
monitor = HDMI-A-1,1920x1080@60,2560x0,1
```

### Default Apps
Edit the `$term`, `$browser`, `$files`, `$editor` variables at the bottom of `hyprland.conf`.

### Autostart
Add/remove entries in the `exec-once` section of `hyprland.conf`.

### Wallpapers
Drop images into `~/.config/hypr/wallpapers/` and press `Super+W` to cycle.

### Colors
All colors are defined in `~/.config/hypr/mocha.conf`. Swap out the Catppuccin palette for any theme of your choice.

---

## Credits

- [Catppuccin](https://github.com/catppuccin/catppuccin) — color theme
- [Hyprland](https://hyprland.org/) — Wayland compositor
- [Waybar](https://github.com/Alexays/Waybar) — status bar
