#!/usr/bin/env bash
###############################################################################
#   ██╗  ██╗██╗   ██╗██████╗ ██╗    ██╗ █████╗ ██████╗ ███████╗            #
#   ██║  ██║╚██╗ ██╔╝██╔══██╗██║    ██║██╔══██╗██╔══██╗██╔════╝            #
#   ███████║ ╚████╔╝ ██████╔╝██║ █╗ ██║███████║██████╔╝█████╗              #
#   ██╔══██║  ╚██╔╝  ██╔═══╝ ██║███╗██║██╔══██║██╔══██╗██╔══╝              #
#   ██║  ██║   ██║   ██║     ╚███╔███╔╝██║  ██║██║  ██║███████╗            #
#   ╚═╝  ╚═╝   ╚═╝   ╚═╝      ╚══╝╚══╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝            #
#                                                                             #
#   hyprware install.sh — automated dotfiles installer                       #
#   Supports: Arch Linux / Arch-based distros                                #
###############################################################################

set -euo pipefail

# ── Colors ────────────────────────────────────────────────────────────────────
BLUE='\033[1;34m'; MAUVE='\033[1;35m'; GREEN='\033[1;32m'
YELLOW='\033[1;33m'; RED='\033[1;31m'; RESET='\033[0m'

info()    { echo -e "${BLUE}[INFO]${RESET}  $*"; }
success() { echo -e "${GREEN}[OK]${RESET}    $*"; }
warn()    { echo -e "${YELLOW}[WARN]${RESET}  $*"; }
error()   { echo -e "${RED}[ERR]${RESET}   $*"; exit 1; }
header()  { echo -e "\n${MAUVE}━━━ $* ━━━${RESET}\n"; }

# ── Sanity checks ─────────────────────────────────────────────────────────────
[[ "$(id -u)" -eq 0 ]] && error "Don't run as root."
command -v pacman &>/dev/null || error "This installer is for Arch Linux only."

DOTFILES_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKUP_DIR="$HOME/.config-backup/$(date +%Y%m%d_%H%M%S)"

header "hyprware — Dotfiles Installer"
echo "  Dotfiles: $DOTFILES_DIR"
echo "  Backups:  $BACKUP_DIR"
echo ""
read -rp "Continue? [y/N] " confirm
[[ "${confirm,,}" == "y" ]] || { echo "Aborted."; exit 0; }

# ── AUR Helper ────────────────────────────────────────────────────────────────
header "AUR Helper"
if ! command -v yay &>/dev/null && ! command -v paru &>/dev/null; then
    info "Installing yay…"
    sudo pacman -S --needed --noconfirm base-devel git
    git clone https://aur.archlinux.org/yay-bin.git /tmp/yay-bin
    (cd /tmp/yay-bin && makepkg -si --noconfirm)
    success "yay installed"
else
    success "AUR helper already present"
fi
AUR="$(command -v paru || command -v yay)"

# ── Packages ──────────────────────────────────────────────────────────────────
header "Core Packages"

PACMAN_PKGS=(
    # Hyprland ecosystem
    hyprland hyprlock hypridle hyprpaper hyprpicker hyprcursor
    xdg-desktop-portal-hyprland xdg-desktop-portal-gtk
    # Wayland utilities
    waybar dunst kitty rofi-wayland
    wl-clipboard wl-clip-persist cliphist
    grim slurp satty hyprshot
    wf-recorder
    swayimg
    # Audio
    pipewire pipewire-alsa pipewire-pulse pipewire-jack wireplumber
    pavucontrol
    # Network / Bluetooth
    networkmanager nm-connection-editor network-manager-applet
    bluez bluez-utils blueman
    # Theming
    qt5ct qt6ct
    nwg-look
    # Fonts
    ttf-jetbrains-mono-nerd
    noto-fonts noto-fonts-emoji noto-fonts-cjk
    # Icons / Cursors
    papirus-icon-theme
    # System utils
    brightnessctl playerctl
    btop fastfetch
    thunar thunar-archive-plugin thunar-volman
    gvfs gvfs-mtp gvfs-smb
    polkit-kde-agent
    # Misc
    python-gobject  # for mediaplayer.py
    jq              # JSON parsing in scripts
    imagemagick     # wallpaper manipulation
)

AUR_PKGS=(
    bibata-cursor-theme-bin
    catppuccin-gtk-theme-mocha
    swaync                      # notification center (optional, used in waybar)
)

info "Installing pacman packages…"
sudo pacman -S --needed --noconfirm "${PACMAN_PKGS[@]}" \
    || warn "Some packages may have failed — check output above"
success "Pacman packages done"

info "Installing AUR packages…"
"$AUR" -S --needed --noconfirm "${AUR_PKGS[@]}" \
    || warn "Some AUR packages may have failed"
success "AUR packages done"

# ── Backup existing configs ────────────────────────────────────────────────────
header "Backing up existing configs"
CONFIGS=(hypr waybar rofi dunst kitty)
mkdir -p "$BACKUP_DIR"

for cfg in "${CONFIGS[@]}"; do
    if [[ -e "$HOME/.config/$cfg" ]]; then
        info "Backing up ~/.config/$cfg"
        cp -r "$HOME/.config/$cfg" "$BACKUP_DIR/"
    fi
done
success "Backups saved to $BACKUP_DIR"

# ── Install dotfiles ───────────────────────────────────────────────────────────
header "Installing dotfiles"

install_config() {
    local src="$1"
    local dst="$HOME/.config/$2"
    info "Installing $2"
    mkdir -p "$(dirname "$dst")"
    cp -r "$src" "$dst"
}

install_config "$DOTFILES_DIR/hypr"   "hypr"
install_config "$DOTFILES_DIR/waybar" "waybar"
install_config "$DOTFILES_DIR/rofi"   "rofi"
install_config "$DOTFILES_DIR/dunst"  "dunst"
install_config "$DOTFILES_DIR/kitty"  "kitty"

# Rename dunstrc to dunst/dunstrc expected location
# (already placed correctly)

success "Dotfiles installed"

# ── Scripts ───────────────────────────────────────────────────────────────────
header "Making scripts executable"
find "$HOME/.config/hypr/scripts" -type f -name "*.sh" -exec chmod +x {} \;
find "$HOME/.config/rofi/scripts" -type f -name "*.sh" -exec chmod +x {} \;
find "$HOME/.config/waybar/scripts" -type f -exec chmod +x {} \;
success "Scripts are executable"

# ── Wallpapers ────────────────────────────────────────────────────────────────
header "Wallpapers"
mkdir -p "$HOME/.config/hypr/wallpapers"
if [[ ! "$(ls -A "$HOME/.config/hypr/wallpapers" 2>/dev/null)" ]]; then
    info "No wallpapers found. Downloading a starter wallpaper…"
    # Use imagemagick to generate a beautiful gradient placeholder
    if command -v magick &>/dev/null || command -v convert &>/dev/null; then
        CMD=$(command -v magick || command -v convert)
        "$CMD" -size 3840x2160 \
            gradient:"#1e1e2e-#313244" \
            -sigmoidal-contrast 3,50% \
            "$HOME/.config/hypr/wallpapers/wallpaper.png"
        success "Generated placeholder wallpaper"
    else
        warn "imagemagick not found. Add a wallpaper to ~/.config/hypr/wallpapers/"
    fi
else
    success "Wallpapers already present"
fi

# ── GTK / Qt theme ───────────────────────────────────────────────────────────
header "Theme"
mkdir -p "$HOME/.config/gtk-3.0" "$HOME/.config/gtk-4.0"

cat > "$HOME/.config/gtk-3.0/settings.ini" << 'EOF'
[Settings]
gtk-theme-name=catppuccin-mocha-blue-standard+default
gtk-icon-theme-name=Papirus-Dark
gtk-font-name=JetBrainsMono Nerd Font 11
gtk-cursor-theme-name=Bibata-Modern-Ice
gtk-cursor-theme-size=24
gtk-toolbar-style=GTK_TOOLBAR_BOTH_HORIZ
gtk-xft-antialias=1
gtk-xft-hinting=1
gtk-xft-hintstyle=hintslight
gtk-xft-rgba=rgb
EOF

cat > "$HOME/.config/gtk-4.0/settings.ini" << 'EOF'
[Settings]
gtk-theme-name=catppuccin-mocha-blue-standard+default
gtk-icon-theme-name=Papirus-Dark
gtk-font-name=JetBrainsMono Nerd Font 11
gtk-cursor-theme-name=Bibata-Modern-Ice
gtk-cursor-theme-size=24
EOF

# Qt themes
mkdir -p "$HOME/.config/qt5ct" "$HOME/.config/qt6ct"
for QT in qt5ct qt6ct; do
    cat > "$HOME/.config/$QT/qt$QT.conf" << 'EOF'
[Appearance]
icon_theme=Papirus-Dark
style=kvantum-dark
EOF
done

success "Theme configured"

# ── Services ──────────────────────────────────────────────────────────────────
header "Enabling services"
systemctl --user enable --now pipewire.service   2>/dev/null || true
systemctl --user enable --now pipewire-pulse.service 2>/dev/null || true
systemctl --user enable --now wireplumber.service 2>/dev/null || true
sudo systemctl enable --now bluetooth.service   2>/dev/null || true
sudo systemctl enable --now NetworkManager.service 2>/dev/null || true
success "Services enabled"

# ── Screenshots directory ────────────────────────────────────────────────────
mkdir -p "$HOME/Pictures/Screenshots"
mkdir -p "$HOME/Videos/Recordings"

# ── Profile face ────────────────────────────────────────────────────────────
header "Lock screen avatar"
if [[ ! -f "$HOME/.face" ]]; then
    warn "No ~/.face found. hyprlock will show no avatar."
    warn "Add a square PNG as ~/.face to display it on the lock screen."
fi

# ── Done ──────────────────────────────────────────────────────────────────────
header "All done!"
echo -e "${GREEN}"
echo "  ██╗  ██╗██╗   ██╗██████╗ ██████╗ ██╗    ██╗ █████╗ ██████╗ ███████╗"
echo "  ██║  ██║╚██╗ ██╔╝██╔══██╗██╔══██╗██║    ██║██╔══██╗██╔══██╗██╔════╝"
echo "  ███████║ ╚████╔╝ ██████╔╝██║  ██║██║ █╗ ██║███████║██████╔╝█████╗  "
echo "  ██╔══██║  ╚██╔╝  ██╔═══╝ ██║  ██║██║███╗██║██╔══██║██╔══██╗██╔══╝  "
echo "  ██║  ██║   ██║   ██║     ██████╔╝╚███╔███╔╝██║  ██║██║  ██║███████╗"
echo "  ╚═╝  ╚═╝   ╚═╝   ╚═╝     ╚═════╝  ╚══╝╚══╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝"
echo -e "${RESET}"
echo ""
echo -e "  ${GREEN}Installation complete!${RESET}"
echo ""
echo -e "  ${BLUE}Next steps:${RESET}"
echo "    1. Log out and select Hyprland from your display manager"
echo "    2. Add wallpapers to ~/.config/hypr/wallpapers/"
echo "    3. Add a profile pic at ~/.face (for hyprlock)"
echo "    4. Adjust monitor config in ~/.config/hypr/hyprland.conf"
echo "    5. Press Super+Space to open the app launcher"
echo ""
echo -e "  ${MAUVE}Key bindings:${RESET}"
printf "    %-28s %s\n" "Super + Return"        "Terminal (kitty)"
printf "    %-28s %s\n" "Super + Space"         "App launcher (rofi)"
printf "    %-28s %s\n" "Super + Shift + E"     "Power menu"
printf "    %-28s %s\n" "Super + B"             "Browser"
printf "    %-28s %s\n" "Super + Q"             "Close window"
printf "    %-28s %s\n" "Super + H/J/K/L"       "Move focus (vim-style)"
printf "    %-28s %s\n" "Super + Shift + H/J/K/L" "Move window"
printf "    %-28s %s\n" "Super + [1-0]"         "Switch workspace"
printf "    %-28s %s\n" "Super + F"             "Fullscreen"
printf "    %-28s %s\n" "Super + Alt + F"       "Toggle float"
printf "    %-28s %s\n" "Super + S"             "Scratchpad"
printf "    %-28s %s\n" "Super + V"             "Clipboard history"
printf "    %-28s %s\n" "Super + Shift + S"     "Screenshot region"
printf "    %-28s %s\n" "Super + Alt + R"       "Record screen"
printf "    %-28s %s\n" "Super + W"             "Random wallpaper"
printf "    %-28s %s\n" "Super + Ctrl + L"      "Lock screen"
printf "    %-28s %s\n" "Super + Shift + R"     "Reload config"
echo ""
echo -e "  Backups of old configs: ${YELLOW}$BACKUP_DIR${RESET}"
echo ""
